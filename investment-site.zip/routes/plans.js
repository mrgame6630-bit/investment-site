const express = require("express");
const jwt = require("jsonwebtoken");

const Plan = require("../models/Plan");
const User = require("../models/User");

const router = express.Router();

// Middleware for authentication
function auth(req, res, next) {
    const token = req.headers["authorization"];
    if (!token) return res.status(401).json({ message: "No token provided" });

    jwt.verify(token, "secretKey", (err, decoded) => {
        if (err) return res.status(403).json({ message: "Invalid token" });
        req.userId = decoded.id;
        next();
    });
}

// Buy a plan
router.post("/buy", auth, async (req, res) => {
    const { name, invest, returnAmount, days } = req.body;

    try {
        const user = await User.findById(req.userId);
        if (user.balance < invest) {
            return res.status(400).json({ message: "Not enough balance" });
        }

        user.balance -= invest;
        await user.save();

        const plan = new Plan({
            userId: req.userId,
            name,
            invest,
            returnAmount,
            startDate: new Date(),
            endDate: new Date(Date.now() + days * 24 * 60 * 60 * 1000),
            paid: false
        });

        await plan.save();
        res.json({ message: "Plan purchased successfully" });
    } catch (err) {
        res.status(500).json({ message: "Server error" });
    }
});

module.exports = router;
