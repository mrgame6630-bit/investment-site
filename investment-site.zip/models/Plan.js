const mongoose = require("mongoose");

const PlanSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    name: String,
    invest: Number,
    returnAmount: Number,
    startDate: Date,
    endDate: Date,
    paid: { type: Boolean, default: false }
});

module.exports = mongoose.model("Plan", PlanSchema);
